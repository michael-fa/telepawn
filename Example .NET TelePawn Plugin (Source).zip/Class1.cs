﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using telepawn;
using telepawn.Scripting;
using telepawn.Plugins;
using telepawn.Utils;
using AMXWrapper;

namespace testplugin
{
    public class Class1
    {

        public string[] NativeList = {"TestPluginTest"};
        public Class1()
        {
            telepawn.Utils.Log.Info("Hello from plugin!");

            
        }

        public string[] GetNatives()
        {
            return NativeList;
        }

        public void OnLoad()
        {
            //We use m_Script[0] because this refers to the always needed and loaded main.amx!
            AMXPublic p = Program.m_Scripts[0].m_Amx.FindPublic("OnTest");
            p.Execute();
        }

        public void OnUnload(int exitcode)
        {

            telepawn.Utils.Log.Info("Unloaded from plugin!");
        }

        public int TestPluginTest(AMX amx1, AMXArgumentList args1)
        {
            telepawn.Utils.Log.WriteLine("Dis is awesome!");
            return 1;
        }
    }
}
